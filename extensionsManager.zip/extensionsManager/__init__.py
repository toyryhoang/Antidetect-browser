class ExtensionsManager:
    def extensionIsAlreadyExisted(self, preferences, profileExtensionsCheck):
        pass